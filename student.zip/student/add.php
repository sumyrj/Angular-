
<?php
	  include 'dbcon.php';
	  header("Access-Control-Allow-Origin: *");
	  header("Access-Control-Allow-Methods: PUT, GET, POST");
	  header("Access-Control-Allow-Headers: Origin,X-Requested-Width,Content-Type,Accept");
	  $postdata=file_get_contents("php://input");
	  if(isset($postdata)&& !empty($postdata))
	  {
	  $request=json_decode($postdata);
	  $name=mysqli_real_escape_string($conn,trim($request->data->name));
	  $password=mysqli_real_escape_string($conn,trim($request->data->password));
	  $email=mysqli_real_escape_string($conn,trim($request->data->email));
	 
	  
		 $sql="INSERT INTO registration(id,name,password,email) VALUES(' ','$name','$password','$email')";
		 // print_r($sql);exit;
		 if(mysqli_query($conn,$sql))
		 {
			 $student=['name'=>$name,'password'=>$password,'email'=>$email,'id'=>mysqli_insert_id($conn)];
			 echo json_encode(['data'=>$student]);
		// $result=mysqli_query($con,$sql);
		 }
	//header("Location:view.php");
	  else
	  {
		  http_response_code(422);
	  }
	  }
	  
	  ?>
	  
