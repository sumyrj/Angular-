<?php
$conn=mysqli_connect("localhost","root","","angular_db");

?>